#ifndef __LANYA_H
#define __LANYA_H	