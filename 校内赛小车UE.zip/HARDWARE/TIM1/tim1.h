#ifndef __TIM1_H
#define __TIM1_H

#include "delay.h"
#include "sys.h" 


#endif

