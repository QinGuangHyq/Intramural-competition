#include "wheel.h"
void LF_Forward(u16 speed)
{
	TIM_SetCompare1(TIM3,0);
	TIM_SetCompare2(TIM3,speed);
}
void RF_Forward(u16 speed)
{
	TIM_SetCompare3(TIM3,speed);
	TIM_SetCompare4(TIM3,0);	
}
void LB_Forward(u16 speed)
{
	TIM_SetCompare1(TIM4,0);
	TIM_SetCompare2(TIM4,speed);
}
void RB_Forward(u16 speed)
{
	TIM_SetCompare3(TIM4,speed);
	TIM_SetCompare4(TIM4,0);	
}
void LF_Back(u16 speed)
{
	TIM_SetCompare1(TIM3,speed);
	TIM_SetCompare2(TIM3,0);
}
void RF_Back(u16 speed)
{
	TIM_SetCompare3(TIM3,0);
	TIM_SetCompare4(TIM3,speed);	
}
void LB_Back(u16 speed)
{
	TIM_SetCompare1(TIM4,speed);
	TIM_SetCompare2(TIM4,0);	
}
void RB_Back(u16 speed)
{
	TIM_SetCompare3(TIM4,0);
	TIM_SetCompare4(TIM4,speed);	
}
void stop(void)
{
	TIM_SetCompare1(TIM4,0);
	TIM_SetCompare2(TIM4,0);	
	TIM_SetCompare3(TIM4,0);
	TIM_SetCompare4(TIM4,0);
	TIM_SetCompare1(TIM3,0);
	TIM_SetCompare2(TIM3,0);
	TIM_SetCompare3(TIM3,0);
	TIM_SetCompare4(TIM3,0);
}

