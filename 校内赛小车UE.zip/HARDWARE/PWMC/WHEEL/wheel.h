#ifndef __WHEEL_H
#define __WHEEL_H	 
#include "sys.h"

//#define LF1 PAout(6)
//#define LF2 PAout(7)


//#define RF1 PBout(0)//��ɫ
//#define RF2 PBout(1)


//#define LB1 PBout(6)
//#define LB2 PBout(7)


//#define RB1 PBout(8)
//#define RB2 PBout(9)

void LF_Forward(u16 speed);
void RF_Forward(u16 speed);
void LB_Forward(u16 speed);
void RB_Forward(u16 speed);


void LF_Back(u16 speed);
void RF_Back(u16 speed);
void LB_Back(u16 speed);
void RB_Back(u16 speed);



#endif


