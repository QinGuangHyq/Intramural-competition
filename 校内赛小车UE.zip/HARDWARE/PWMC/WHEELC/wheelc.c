#include "wheelc.h"

void usart_speed(int speed)
{
	switch(speed)
	{
		case 1000:forward(1000);break;
		case 500:forward(500);break;
		case -500:back(500);break;
		case -1000:back(1000);break;
	}
}

void usart_zhuan(int speed)
{
	switch(speed)
	{
		case 1000:youzhuan(1000);break;
		case 1200:youyi_s(1200);break;
		case -1200:zuoyi_s(1200);break;
		case -1000:zuozhuan(1000);break;
	}
}
void usart_rocker(int a,int speed)
{
	switch(a)
	{
		case 1:zuoqian(speed+300);break;
		case 2:back(speed);break;
		case 3:youqian(speed+300);break;
		case 4:zuoyi(speed+300);break;
		case 5:youyi(speed+300);break;
		case 6:zuohou(speed+300);break;
		case 7:forward(speed);break;
		case 8:youhou(speed+300);break;	
	}
}
void zuoqian(int speed)
{
	RF_Back(speed);
	LB_Back(speed);
}
void youqian(int speed)
{
	LF_Back(speed);
	RB_Back(speed);
}
void zuohou(int speed)
{
	LF_Forward(speed);
	RB_Forward(speed);
}
void youhou(int speed)
{
	RF_Forward(speed);
	LB_Forward(speed);

}
void forward(u16 speed)
{
	LF_Forward(speed);
	RF_Forward(speed);
	LB_Forward(speed);
	RB_Forward(speed);
}
void back(u16 speed)
{
	LF_Back(speed);
	RF_Back(speed);
	LB_Back(speed);
	RB_Back(speed);
}
void zuoyi(u16 speed)
{
	LB_Back(speed);
	RB_Forward(speed);
	RF_Back(speed);
	LF_Forward(speed);
}
void youyi(u16 speed)
{

	LF_Back(speed);
	RF_Forward(speed);
	RB_Back(speed);
	LB_Forward(speed);	
}
void zuoyi_s(u16 speed)
{
	LB_Back(speed+100);
	RB_Forward(speed);
	RF_Back(speed+100);
	LF_Forward(speed);
}
void youyi_s(u16 speed)
{

	LF_Back(speed+100);
	RF_Forward(speed);
	RB_Back(speed+100);
	LB_Forward(speed);	
}
void zuozhuan(u16 speed)
{
	LB_Back(speed);
	RB_Forward(speed);
	RF_Forward(speed);
	LF_Back(speed);
}
void youzhuan(u16 speed)
{

	LB_Forward(speed);
	RB_Back(speed);
	RF_Back(speed);
	LF_Forward(speed);
}

