#ifndef __GPIO_H
#define __GPIO_H

#include "delay.h"
#include "sys.h" 

void GOIP_Init(void);

#define Forword PBin(8)

#define Back PAin(1)

#define Left PAin(0)

#define Right PBin(9)

#define SE1_Up PBin(1)

#define SE1_Down PBin(0)

#define SE2_Up PAin(7)

#define SE2_Down PAin(6)

#define SE3_Up PAin(5)

#define SE3_Down PAin(4)


#endif

