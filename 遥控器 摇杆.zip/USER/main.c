#include "stm32f10x.h"
#include "gpio.h"
#include "adc.h"

void uart1_init(u32 bound)
{
  //GPIO�˿�����
    GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	 
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);	//ʹ��USART1��GPIOAʱ��
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1,ENABLE);
	//USART1_TX   GPIOA.9��ʼ��
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9; 
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;	//�����������
    GPIO_Init(GPIOA, &GPIO_InitStructure);//��ʼ��GPIOA.9
   
    //USART1_RX	  GPIOA.10��ʼ��
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;//��������
    GPIO_Init(GPIOA, &GPIO_InitStructure);//��ʼ��GPIOA.10  

    //Usart1 NVIC ����
    NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=3 ;//��ռ���ȼ�3
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;		//�����ȼ�3
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;			//IRQͨ��ʹ��
	NVIC_Init(&NVIC_InitStructure);	//����ָ���Ĳ�����ʼ��VIC�Ĵ���
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_3);	
	//USART ��ʼ������

	USART_InitStructure.USART_BaudRate = bound;//���ڲ�����
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;//�ֳ�Ϊ8λ���ݸ�ʽ
	USART_InitStructure.USART_StopBits = USART_StopBits_1;//һ��ֹͣλ
	USART_InitStructure.USART_Parity = USART_Parity_No;//����żУ��λ
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;//��Ӳ������������
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;	//�շ�ģʽ

	USART_Init(USART1, &USART_InitStructure); //��ʼ������1
	USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);//�������ڽ����ж�
	USART_Cmd(USART1, ENABLE);                    //ʹ�ܴ���1 

}
int main(void)
{
	u8 in=0;
	u16 ADx,ADy;
	Adc_Init();	
    uart1_init(38400);
	delay_init();
	GOIP_Init();
	while(1)
	{
		ADx=Get_Adc(ADC_Channel_2);
		ADy=Get_Adc(ADC_Channel_3);
		if(Forword==0)
		{
			do
			{
				USART_SendData(USART1,0x31);		
			}
			while(Forword==0);
			USART_SendData(USART1,0x30);			
		}
		else if(Back==0)
		{
			do
			{
				USART_SendData(USART1,0x32);
			}
			while(Back==0);
			USART_SendData(USART1,0x30);			
		}	
		else if(Left==0)
		{
			do
			{
				USART_SendData(USART1,0x36);		
			}				
			while(Left==0);
			USART_SendData(USART1,0x30);			
		}
		else if(Right==0)
		{
			do
			{
				USART_SendData(USART1,0x38);
			}
			while(Right==0);
			USART_SendData(USART1,0x30);				
		}	
		else if(SE1_Up==0)
		{
			do
			{
				USART_SendData(USART1,0x61);	
			}
			while(SE1_Up==0);
			USART_SendData(USART1,0x30);	
		}
		else if(SE1_Down==0)
		{	
			do			
			{
				USART_SendData(USART1,0x62);
			}
			while(SE1_Down==0);
			USART_SendData(USART1,0x30);			
		}
		else if(SE2_Up==0)
		{		
			do
			{
				USART_SendData(USART1,0x63);	
			}
			while(SE2_Up==0);
			USART_SendData(USART1,0x30);			
		}
		else if(SE2_Down==0)
		{	
			do
			{	
				USART_SendData(USART1,0x64);
			}
			while(SE2_Down==0);
			USART_SendData(USART1,0x30);			
		}
		else if(SE3_Up==0)
		{		
			do
			{
				USART_SendData(USART1,0x65);	
			}
			while(SE3_Up==0);
			USART_SendData(USART1,0x30);				
		}
		else if(SE3_Down==0)
		{					
			do
			{
				USART_SendData(USART1,0x66);
			}
			while(SE3_Down==0);
			USART_SendData(USART1,0x30);				
		}		
		if((1500<=ADx&&ADx<=3500)&&(1500<=ADy&&ADy<=3500)&&(in == 1)) //�м�
		{
			USART_SendData(USART1,0x30);
			in=0;
		}
		else if(ADx<=1500&&ADy<=1500)			//��ǰ
		{
			USART_SendData(USART1,0x68);
			in=1;		
		}
		else if((1500<=ADx&&ADx<=3500)&&(ADy<=1500))		//ǰ
		{
			USART_SendData(USART1,0x69);
			in=1;		
		}
		else if(ADx>=3500&&ADy<=1500)			//��ǰ
		{
			USART_SendData(USART1,0x70);
			in=1;		
		}
		else if((ADx<=1500)&&(1500<=ADy&&ADy<=3500))		//��
		{
			USART_SendData(USART1,0x71);
			in=1;		
		}
		else if((ADx>=3500)&&(1500<=ADy&&ADy<=3500))		//��
		{
			USART_SendData(USART1,0x72);
			in=1;		
		}
		else if((ADx<=1500)&&(ADy>=3500))		//���
		{
			USART_SendData(USART1,0x73);
			in=1;		
		}
		else if((1500<=ADx&&ADx<=3500)&&(ADy>=3500))		//��
		{
			USART_SendData(USART1,0x74);
			in=1;		
		}
		else if((ADx>=3500)&&(ADy>=3500))		//�Һ�
		{
			USART_SendData(USART1,0x75);
			in=1;		
		}			
		
	}
}

